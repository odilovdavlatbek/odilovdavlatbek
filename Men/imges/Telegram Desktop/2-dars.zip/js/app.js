// let, const, var*
// ! let - kalit so'zi bilan elon qilingan o'zgaruvchilardi qayta malumotni o'zgartirish mumkin lekin osha nomdagi o'zgaruvchini elon qilib bo'lmaydi.
// let age = 18;
// age = 19
// let ism = "Abdusalom";
// ? const o'zgaruvchisi o'zgarmas
// const from = "Uzbekistan";
// const sana = 2005
//? JavaScriptda 8 ta malumot turi mavjud va ulardan 7 tasi primitive hamda 1 tasi reference turhga kiradi.
// primitive
// number - 1,2,3,4
let age = 18;
// string - "Malumot"
let ism = "Abdusalom";
ism = "Odilbek"
// boolean(true,false)
let oila = false;
let farzand;
console.log(farzand);

// undifined - o'zgaruvchi elon qilingan lekin uning qiymati yo'q
// null - hech qanday malumot
// bigInt - 9000000010n
// symbol() - unik- takrorlanmas malumot turlarini yaratish uchun ishlatiladi.

// reference
//object()
const fullAbout = {
    age: 18,
    ism: 'Abdusalom',
    farzand: true,

}